package com.sse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SSEServlet
 */
public class SSEServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SSEServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/event-stream");
		response.setCharacterEncoding("UTF-8");
		PrintWriter printwriter=null; 
		while(true){
			try{
			double randomNumber = Math.random()*10000;	
			printwriter=response.getWriter();
			printwriter.print("data: "+ "[next server time check event in : "+ Math.round(randomNumber) + "\n\n");
			printwriter.print("data: "+ "Time: "+ Calendar.getInstance().getTime() + "\n\n");
			Thread.sleep((long)randomNumber);
			response.flushBuffer();
			}
			catch(Exception e){
				printwriter.close();
				break;
			}
		}
	}

}
