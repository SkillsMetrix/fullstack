$(document).ready(function() {
$("#btnSave").attr('disabled', 'disabled');
$("form").keyup(function() {
// To Disable Submit Button
$("#btnSave").attr('disabled', 'disabled');
// Validating Fields
var id = $("#txtID").val();
var name = $("#txtName").val();
var phone = $("#txtPhone").val();
var email = $("#txtEmail").val();

var filter = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
if (!(name == "" || email == "" || id == ""|| phone == "")) {
if (filter.test(email)) {
// To Enable Submit Button
$("#btnSave").removeAttr('disabled');
$("#btnSave").css({
"cursor": "pointer",
"box-shadow": "1px 0px 6px #333"
});
}
}
});
// On Click Of Submit Button
$("#btnSave").click(function() {
$("#btnSave").css({
"cursor": "default",
"box-shadow": "none"
});
alert("Form Submitted Successfully..!!");
});
});