for(var i=0; i<1000; i +=1) {

	var j =i;
}
postMessage(j);